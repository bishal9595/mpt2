import { Injectable } from '@angular/core';

@Injectable({
  providedIn:'root'


})
export class MusicService
{
    
    
    constructor( )
    {
        
    }


    albumAll:any[]=[];   // album array

    
   
// For Retrieving Album Details
  getAllMusicDetails()
   {
          
           return this.albumAll;
   }


   addMusic(data:any):any
   {
       
      
       this.albumAll.push(data);
       return true;
       
   }
  
   
}