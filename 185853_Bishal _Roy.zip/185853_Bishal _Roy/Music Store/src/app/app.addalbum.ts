import { Component} from "@angular/core";
import {MusicService} from './app.musicservice';
import { Router } from '@angular/router'
@Component({selector:'add-comp',
templateUrl:'app.addalbum.html'})

export class AddMusicComponenent   
{
    constructor(private service:MusicService,private router:Router)
    {
       
    } 
    myAllData:any;        // Album array
    albumId:number;     // Album Id variable
    albumTitle:string;   // Album Title variable
    albumPrice:number;   // Album Price variable
    albumArtist:string;  // Album Artist variable
    
    // Method for Adding details of album 
    addData()
    {   this. myAllData={albumId:this.albumId,albumTitle:this.albumTitle,albumArtist:this.albumArtist,albumPrice:this.albumPrice}
        if(this.service.addMusic(this.myAllData))
        {
           this.router.navigate(['show'])
        }
    }
   
  
  
    
    

  
}