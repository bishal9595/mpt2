import { Component,OnInit} from "@angular/core";
import {MusicService} from './app.musicservice';

@Component({selector:'show-comp',
templateUrl:'app.showalbum.html'})

export class ShowMusicComponenent implements OnInit
{
 
  constructor(private myservice:MusicService)
  {

  }

  albumAll:any[]=[];
  data:any
  ngOnInit()
  {
      this.albumAll=this.myservice.getAllMusicDetails();
    
  }

  // Deleting album record
  deleteAlbum(data:number)                
  {
    alert("Are You Sure You want To delete?")
    this.albumAll.splice(data,1)
    
  }
  
 
}