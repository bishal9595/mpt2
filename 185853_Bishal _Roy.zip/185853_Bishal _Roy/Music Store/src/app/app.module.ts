﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {AddMusicComponenent} from './app.addalbum'
import {ShowMusicComponenent} from './app.showalbum'
import{FormsModule} from '@angular/forms';
import {Routes,RouterModule} from '@angular/router'
const routes:Routes=[{path:'',redirectTo:'show',pathMatch:'full'},
        {path:'add',component:AddMusicComponenent},
        {path:'show',component:ShowMusicComponenent},
        ];
@NgModule({
    imports: [
        BrowserModule,FormsModule,RouterModule.forRoot(routes)
        
    ],
    declarations: [
        AppComponent,AddMusicComponenent,ShowMusicComponenent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }